package com.cg.project.exception;

@SuppressWarnings("serial")
public class InsuranceException extends Exception {
	
	public InsuranceException(String message){
		super(message);
	}
	
	public InsuranceException(){
		super();
	}

}
